const express = require("express");
require("./db/conn");
const Student = require("./modals/student")
const studentRouter = require("./routers/student");

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json())



//3. we need to register our router 
app.use(studentRouter);



app.listen(3000, function() {
    console.log("Server is running on port " + 3000);
});
