const express = require("express");
const Student = require("../modals/student");

// 1. create a new router 
const router = new express.Router();
// 2. we need to define the router 
router.get("/manish",(req,res)=>{
    res.send("Hello , whatsup guys");
});
//3rd part app.js me h iska 


router.get("/", (req,res)=>{
    res.send("hello from the server side by manish mmljlaxxkjflj ");
 
 })
 
 //student registration krna h by using promises 
 router.post("/students",(req,res)=>{
    console.log(req.body)
 
     const user = new Student(req.body)
     user.save().then(()=>{
         res.status(201)
         res.send(user);
     }).catch((e)=>{
         res.status(400)
         res.send(e);
     })  
     
     
    // res.send("hello from the other side ");
 })
 
 
 
 /* student registration-> storing data into database using async await function 
 router.post("/students",async(req,res)=>{
     try{
 
         const user = new Student(req.body);
         const createUser = await user.save();
         res.status(201).send(createUser);
         console.log(createUser);
 
     }catch(e){
         res.status(400).send(e);
 
     }
 })   */
 
 
 
 
 //read the data of registered students 
 router.get("/students", async(req,res)=>{
     try{
 
       const studentsData =   await Student.find();
       res.send(studentsData);
       console.log(studentsData);
 
     }catch(e){
         res.send(e);
 
     }
 })
 
 
 //get the individuals Student data using id
 router.get("/students/:id",async(req,res)=>{
     try{
            const _id = req.params.id;
            
              const studentData = await Student.findById({_id:_id});
 
              if(!studentData){
                 return res.status(404).send();
              }
              else{
 
                 res.send(studentData);
         
              }
             
 
     }catch(e){
         res.status(500).send(e);
 
     }
 })
 
 
 
 
 //update the students by its id 
 router.patch("/students/:id",async(req,res)=>{
 
     try{
         const _id = req.params.id;
         const {email} = req.body
         const updateStudents =  await Student.findByIdAndUpdate({_id:_id},{$set:{email:email}});
         res.send(updateStudents);
         console.log(updateStudents);
 
         
 
     }catch(e){
 
 
          res.status(400).send();
     }
 
 })
 
 
 
 
 
 //delete the students by it id
 router.delete("/students/:id",async(req,res)=>{
 
     try{
         const id = req.params.id;
          const deleteStudent = await Student.findByIdAndDelete(id);
          if(!req.params.id){
             return res.status(404).send();
 
          }
          res.send(deleteStudent);
 
     }catch(e){
         res.status(500).send(e);
 
     }
 
 })


module.exports = router;